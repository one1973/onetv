# -*- coding: utf-8 -*-
import sys
import re
import os
import json
import socket
import threading
import tempfile
import urllib.parse
import requests
from bs4 import BeautifulSoup
from http.server import HTTPServer, BaseHTTPRequestHandler
import xbmc
import xbmcgui
import xbmcplugin
import time
import xbmcvfs
# =====================================================================
# CONFIGURACIÓN
# =====================================================================
YT_DLP_PATH = r"C:\yt-dlp\yt-dlp.exe"
BASE_URL = "https://reypelis.net"
USER_AGENT = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"

HANDLE = int(sys.argv[1])
ADDON_URL = sys.argv[0]

SESSION = requests.Session()
SESSION.headers.update({"User-Agent": USER_AGENT, "Accept-Language": "es-ES,es;q=0.9"})

# =====================================================================
# PROXY LOCAL
# =====================================================================
# =====================================================================
# PROXY LOCAL (CORREGIDO)
# =====================================================================
# =====================================================================
# PROXY LOCAL (CORREGIDO DEFINITIVO)
# =====================================================================
PROXY_PORT = 54321
PROXY_REFERER = ""
_proxy_server = None
_proxy_thread = None

class ProxyHandler(BaseHTTPRequestHandler):
    def log_message(self, format, *args):
        pass

    def do_GET(self):
        global PROXY_REFERER
        try:
            # 1. Extraer la URL de destino
            target_url = self.path
            if "url=" in target_url:
                target_url = urllib.parse.unquote(target_url.split("url=", 1)[1])
            
            xbmc.log(f"Reypelis-Proxy: Petición para {target_url}", xbmc.LOGINFO)

            # 2. Hacer la petición a Fastream con las cabeceras
            headers = {
                "User-Agent": USER_AGENT,
                "Referer": PROXY_REFERER,
                "Origin": "https://fastream.to",
                "Accept": "*/*",
                "Accept-Language": "es-ES,es;q=0.9",
            }

            r = requests.get(target_url, headers=headers, stream=True, timeout=30, allow_redirects=True)

            xbmc.log(f"Reypelis-Proxy: Respuesta de Fastream: {r.status_code}", xbmc.LOGINFO)

            if r.status_code != 200:
                self.send_response(r.status_code)
                self.end_headers()
                return

            # 3. Comprobar si es un .m3u8 (texto) o un segmento .ts (binario)
            if target_url.endswith(".m3u8") or "m3u8" in target_url:
                content = r.text
                # 4. Reescribir las URLs internas para que apunten al proxy
                new_lines = []
                for line in content.splitlines():
                    line = line.strip()
                    if not line:
                        continue
                    if line.startswith("#"):
                        # Es un comentario/directiva. Revisar si contiene URIs (I-FRAME-STREAM-INF, etc.)
                        # Ejemplo: #EXT-X-I-FRAME-STREAM-INF:...,URI="https://..."
                        if 'URI="' in line:
                            # Extraer la URI y envolverla en el proxy
                            def replace_uri(m):
                                inner_url = m.group(1)
                                proxied = f"http://127.0.0.1:{PROXY_PORT}/proxy?url={urllib.parse.quote(inner_url, safe='')}"
                                return f'URI="{proxied}"'
                            line = re.sub(r'URI="([^"]+)"', replace_uri, line)
                        new_lines.append(line)
                    else:
                        # Es una URL (segmento .ts o sub-playlist .m3u8)
                        if line.startswith("http"):
                            inner_url = line
                        elif line.startswith("/"):
                            inner_url = "https://s40.fastream.to" + line
                        else:
                            # Relativa al directorio del m3u8 actual
                            base = target_url.rsplit("/", 1)[0] + "/"
                            inner_url = base + line
                        
                        proxied = f"http://127.0.0.1:{PROXY_PORT}/proxy?url={urllib.parse.quote(inner_url, safe='')}"
                        new_lines.append(proxied)

                new_content = "\n".join(new_lines).encode("utf-8")
                
                self.send_response(200)
                self.send_header("Content-Type", "application/vnd.apple.mpegurl")
                self.send_header("Content-Length", str(len(new_content)))
                self.end_headers()
                self.wfile.write(new_content)
                xbmc.log(f"Reypelis-Proxy: m3u8 reescrito y enviado ({len(new_content)} bytes)", xbmc.LOGINFO)
            else:
                # 5. Es un segmento .ts (binario). Enviarlo tal cual.
                self.send_response(r.status_code)
                for k, v in r.headers.items():
                    if k.lower() not in ("transfer-encoding", "connection", "content-encoding"):
                        self.send_header(k, v)
                self.end_headers()
                for chunk in r.iter_content(chunk_size=8192):
                    if chunk:
                        self.wfile.write(chunk)

        except Exception as e:
            xbmc.log(f"Reypelis-Proxy: ERROR: {e}", xbmc.LOGERROR)
            try:
                self.send_response(500)
                self.end_headers()
            except:
                pass

def start_proxy(referer):
    global _proxy_server, _proxy_thread, PROXY_REFERER
    PROXY_REFERER = referer
    if _proxy_server is not None:
        return
    try:
        _proxy_server = HTTPServer(("127.0.0.1", PROXY_PORT), ProxyHandler)
        _proxy_thread = threading.Thread(target=_proxy_server.serve_forever, daemon=True)
        _proxy_thread.start()
        xbmc.log(f"Reypelis: Proxy iniciado en http://127.0.0.1:{PROXY_PORT} con Referer={referer}", xbmc.LOGINFO)
    except Exception as e:
        xbmc.log(f"Reypelis: Error iniciando proxy: {e}", xbmc.LOGERROR)

# =====================================================================
# UTILIDADES
# =====================================================================
def download(url, title):
    """
    Descarga una película o episodio en una ruta fija dentro del perfil de Kodi.
    """
    xbmc.log(f"Reypelis-Download: Iniciando descarga de {title} desde {url}", xbmc.LOGINFO)
    
    soup = get_soup(url)
    if not soup:
        xbmcgui.Dialog().ok("Reypelis", "No se pudo acceder a la página de detalle.")
        return

    # 1. Buscar enlaces de descarga
    download_links = []
    for a in soup.find_all("a", href=True):
        href = a["href"]
        if "trdownload" in href:
            if href.startswith("/"):
                href = BASE_URL + href
            download_links.append(href)

    if not download_links:
        xbmcgui.Dialog().ok("Reypelis", "No se encontraron enlaces de descarga para este título.")
        return

    selected_link = download_links[0]

    # 2. Ruta fija segura
    try:
        user_home = os.path.expanduser("~")
        save_path = os.path.join(user_home, "Downloads", "Reypelis")
        if not os.path.exists(save_path):
            os.makedirs(save_path)
    except Exception as e:
        xbmcgui.Dialog().ok("Reypelis", f"No se pudo crear la carpeta de descargas:\n{e}")
        return

    # 3. Crear nombre de archivo seguro
    safe_title = re.sub(r'[\\/*?:"<>|]', "", title).strip()
    if not safe_title:
        safe_title = "descarga_reypelis"
    file_path = os.path.join(save_path, safe_title + ".mp4")

    # 4. Diálogo de progreso
    dp = xbmcgui.DialogProgress()
    dp.create("Reypelis", f"Descargando: {title}")
    
    cancelled = [False]

    def download_worker():
        try:
            headers = {
                "User-Agent": USER_AGENT,
                "Referer": url,
                "Origin": "https://reypelis.net"
            }
            r = SESSION.get(selected_link, headers=headers, stream=True, timeout=30, allow_redirects=True)
            r.raise_for_status()
            
            total_size = int(r.headers.get('content-length', 0))
            
            with open(file_path, 'wb') as f:
                downloaded = 0
                for chunk in r.iter_content(chunk_size=1024*512):
                    if dp.iscanceled():
                        cancelled[0] = True
                        break
                    if chunk:
                        f.write(chunk)
                        downloaded += len(chunk)
                        # CORRECCIÓN: dp.update() con SOLO 2 argumentos
                        if total_size > 0:
                            percent = int((downloaded / total_size) * 100)
                            dp.update(percent, f"{downloaded // (1024*1024)} MB de {total_size // (1024*1024)} MB")
                        else:
                            dp.update(0, f"{downloaded // (1024*1024)} MB descargados")
            
            dp.close()
            if cancelled[0]:
                if os.path.exists(file_path):
                    os.remove(file_path)
                xbmcgui.Dialog().notification("Reypelis", "Descarga cancelada", xbmcgui.NOTIFICATION_WARNING, 3000)
            else:
                xbmcgui.Dialog().notification(
                    "Reypelis", 
                    f"Descarga completada:\n{file_path}", 
                    xbmcgui.NOTIFICATION_INFO, 
                    8000
                )

        except PermissionError:
            dp.close()
            xbmcgui.Dialog().ok("Reypelis", f"No se pudo escribir el archivo en:\n{file_path}\n\nRevisa los permisos de la carpeta.")
        except Exception as e:
            dp.close()
            if os.path.exists(file_path):
                try: os.remove(file_path)
                except: pass
            xbmcgui.Dialog().ok("Reypelis", f"Error al descargar:\n{str(e)}")

    t = threading.Thread(target=download_worker)
    t.daemon = True
    t.start()
    
def build_url(params):
    return f"{ADDON_URL}?{urllib.parse.urlencode(params)}"

def get_soup(url):
    try:
        r = SESSION.get(url, timeout=15)
        r.raise_for_status()
        return BeautifulSoup(r.text, "html.parser")
    except Exception as e:
        xbmcgui.Dialog().notification("Reypelis", f"Error: {e}", xbmcgui.NOTIFICATION_ERROR, 5000)
        return None

def unpack_js(packed_js):
    pattern = r"eval\(function\(p,a,c,k,e,d\).*?\}\('(.*?)',(\d+),(\d+),'(.*?)'\.split\('\|'\)"
    match = re.search(pattern, packed_js, re.DOTALL)
    if not match:
        return None
    payload, base, count, symtab_raw = match.groups()
    base = int(base)
    symtab = symtab_raw.split('|')
    def decode_char(c):
        if c.isdigit(): return int(c)
        elif c.isalpha(): return ord(c) - 87 if c.islower() else ord(c) - 29
        else: return 0
    def decode_word(word):
        result = []
        i = 0
        while i < len(word):
            c = word[i]
            if c.isalnum():
                num_str = c
                i += 1
                while i < len(word) and word[i].isalnum():
                    num_str += word[i]
                    i += 1
                index = 0
                for char in num_str:
                    index = index * base + decode_char(char)
                if index < len(symtab) and symtab[index]:
                    result.append(symtab[index])
                else:
                    result.append(num_str)
            else:
                result.append(c)
                i += 1
        return ''.join(result)
    return re.sub(r'\b\w+\b', lambda m: decode_word(m.group(0)), payload)

# =====================================================================
# MENÚS Y LISTADOS
# =====================================================================
def main_menu():
    items = [
        ("Películas", {"action": "list", "url": f"{BASE_URL}/cartelera-peliculas/"}),
        ("Series",    {"action": "list", "url": f"{BASE_URL}/cartelera-series/"}),
        ("Géneros",   {"action": "genres"}),  # <-- NUEVO
        ("Buscar",    {"action": "search"}),
    ]
    for label, params in items:
        li = xbmcgui.ListItem(label=label)
        xbmcplugin.addDirectoryItem(HANDLE, build_url(params), li, isFolder=True)
    xbmcplugin.endOfDirectory(HANDLE)

def search():
    kb = xbmc.Keyboard("", "Buscar en Reypelis")
    kb.doModal()
    if kb.isConfirmed() and kb.getText():
        url = f"{BASE_URL}/?s={urllib.parse.quote_plus(kb.getText())}"
        list_content(url)

def list_genres():
    """
    Extrae los géneros del menú de navegación de Reypelis.
    """
    soup = get_soup(BASE_URL)  # Usamos la página principal para obtener el menú
    if not soup:
        return

    # Buscamos el <li> del menú que contiene el texto "Generos"
    genres_found = False
    for li in soup.select("ul.menu > li"):
        link = li.find("a")
        if link and "generos" in link.get_text(strip=True).lower():
            # Dentro de este <li> está el <ul class="sub-menu"> con los géneros
            submenu = li.select_one("ul.sub-menu")
            if submenu:
                for genre_link in submenu.select("a"):
                    genre_name = genre_link.get_text(strip=True)
                    genre_url = genre_link.get("href", "")
                    if genre_url.startswith("/"):
                        genre_url = BASE_URL + genre_url
                    
                    # Añadimos cada género como un ítem de carpeta que llamará a list_content
                    li_item = xbmcgui.ListItem(label=genre_name)
                    params = {"action": "list", "url": genre_url}
                    xbmcplugin.addDirectoryItem(HANDLE, build_url(params), li_item, isFolder=True)
                genres_found = True
                break

    if not genres_found:
        # Fallback: si no se encuentra el menú, mostramos un mensaje
        li = xbmcgui.ListItem(label="No se pudieron cargar los géneros")
        xbmcplugin.addDirectoryItem(HANDLE, "", li, isFolder=False)

    xbmcplugin.endOfDirectory(HANDLE)
    
def list_content(url):
    soup = get_soup(url)
    if not soup:
        return

    # 1. Mostrar las películas de la página actual
    for article in soup.select("article.post"):
        title_tag = article.select_one("h2.entry-title")
        link_tag = article.select_one("a.lnk-blk")
        img_tag = article.select_one(".post-thumbnail img")
        if not (title_tag and link_tag):
            continue
        title = title_tag.get_text(strip=True)
        movie_url = link_tag["href"]
        thumb = img_tag["src"] if img_tag else ""
        if thumb.startswith("//"):
            thumb = "https:" + thumb
        
        li = xbmcgui.ListItem(label=title)
        li.setArt({"thumb": thumb, "icon": thumb})
        li.setInfo("video", {"title": title})
        
        # --- NUEVO: Añadir opción de descarga al menú contextual ---
        # Creamos una URL interna que llamará a la acción "download"
        download_url = build_url({"action": "download", "url": movie_url, "title": title})
        li.addContextMenuItems([("Descargar", f"RunPlugin({download_url})")])
        # -----------------------------------------------------------

        params = {"action": "detail", "url": movie_url, "title": title}
        xbmcplugin.addDirectoryItem(HANDLE, build_url(params), li, isFolder=True)

    # 2. Buscar el enlace "SIGUIENTE" en la paginación
    next_page_url = None
    # Buscamos todos los enlaces de la página y filtramos por el que contiene "SIGUIENTE"
    for a in soup.find_all("a", href=True):
        text = a.get_text(strip=True).upper()
        if "SIGUIENTE" in text or "NEXT" in text:
            href = a["href"]
            if href.startswith("/"):
                next_page_url = BASE_URL + href
            else:
                next_page_url = href
            break

    # 3. Si existe, añadir el ítem "Página Siguiente"
    if next_page_url:
        li_next = xbmcgui.ListItem(label="[COLOR yellow]Página Siguiente >>[/COLOR]")
        params_next = {"action": "list", "url": next_page_url}
        xbmcplugin.addDirectoryItem(HANDLE, build_url(params_next), li_next, isFolder=True)
    else:
        # Si no hay siguiente página, no hacemos nada (o podríamos añadir un mensaje)
        pass

    xbmcplugin.endOfDirectory(HANDLE)

def detail(url, title):
    """
    Decide si es una película o una serie según la URL.
    """
    if "/serie/" in url:
        detail_series(url, title)
    else:
        detail_movie(url, title)

def detail_movie(url, title):
    # ... (Tu código actual de detail() para películas, sin cambios)
    soup = get_soup(url)
    if not soup: return

    plot = ""
    desc = soup.select_one("div.description p")
    if desc: plot = desc.get_text(strip=True)
    
    year = ""
    y_tag = soup.select_one("span.year")
    if y_tag: year = y_tag.get_text(strip=True)

    options = []
    for div in soup.select("div.video.aa-tb"):
        iframe = div.select_one("iframe")
        if not iframe: continue
        src = iframe.get("data-src") or iframe.get("src")
        if not src: continue
        
        div_id = div.get("id", "")
        opt_link = soup.select_one(f'ul.aa-tbs-video a[href="#{div_id}"]')
        lang = "Opción"
        if opt_link:
            server_span = opt_link.select_one("span.server")
            if server_span:
                lang = server_span.get_text(strip=True).strip("-").strip()
        
        options.append({"url": src, "lang": lang})

    if not options:
        xbmcgui.Dialog().ok("Reypelis", "No se encontraron servidores.")
        return

    for opt in options:
        li = xbmcgui.ListItem(label=opt["lang"])
        li.setInfo("video", {"title": title, "plot": plot, "year": year})
        params = {"action": "play", "url": opt["url"], "title": title}
        xbmcplugin.addDirectoryItem(HANDLE, build_url(params), li, isFolder=False)
    xbmcplugin.endOfDirectory(HANDLE)
    
def detail_series(url, title):
    """
    Muestra la lista de temporadas de una serie.
    """
    soup = get_soup(url)
    if not soup: return

    plot = ""
    desc = soup.select_one("div.description p")
    if desc: plot = desc.get_text(strip=True)

    # 1. Buscar el menú de temporadas en el HTML
    seasons = []
    # El menú desplegable tiene la clase "aa-cnt sub-menu" dentro de "choose-season"
    season_menu = soup.select_one(".choose-season .aa-cnt")
    if season_menu:
        for a in season_menu.select("a"):
            # Extraemos el número de temporada del atributo "data-season"
            season_num = a.get("data-season")
            if season_num:
                seasons.append(season_num)

    if not seasons:
        xbmcgui.Dialog().ok("Reypelis", "No se encontraron temporadas para esta serie.")
        return

    # 2. Mostrar cada temporada como un ítem de carpeta
    for s_num in seasons:
        season_label = f"Temporada {s_num}"
        li = xbmcgui.ListItem(label=season_label)
        li.setInfo("video", {"title": season_label, "plot": plot})
        
        # Le pasamos a list_episodes la URL base de la serie, el número de temporada y el título
        params = {"action": "list_episodes", "url": url, "season": s_num, "title": title}
        xbmcplugin.addDirectoryItem(HANDLE, build_url(params), li, isFolder=True)

    xbmcplugin.endOfDirectory(HANDLE)

def list_episodes(url, season_num, series_title):
    """
    Muestra los episodios de una temporada concreta.
    """
    soup = get_soup(url)
    if not soup: return

    plot = ""
    desc = soup.select_one("div.description p")
    if desc: plot = desc.get_text(strip=True)

    episodes = []

    # 1. Si es la Temporada 1, los episodios ya están en el HTML de la página.
    # Buscamos todos los artículos de episodios que correspondan a esta temporada.
    for article in soup.select("article.episodes"):
        title_tag = article.select_one("h2.entry-title")
        link_tag = article.select_one("a.lnk-blk")
        num_tag = article.select_one("span.num-epi")
        
        if title_tag and link_tag and num_tag:
            ep_title = title_tag.get_text(strip=True)
            ep_url = link_tag["href"]
            ep_num_str = num_tag.get_text(strip=True) # Ej: "1x1"
            
            # Verificar que el episodio pertenece a la temporada que buscamos
            if ep_num_str.startswith(f"{season_num}x"):
                ep_num = ep_num_str.split("x")[1]
                episodes.append({"num": ep_num, "title": ep_title, "url": ep_url})

    # 2. Si no encontramos episodios (porque es otra temporada cargada por AJAX),
    # construimos las URLs manualmente basándonos en el patrón de la web.
    if not episodes:
        # Necesitamos saber cuántos episodios tiene la temporada.
        # Como no podemos saberlo sin AJAX, asumiremos un número alto (ej. 30)
        # y comprobaremos si la URL existe. Esto es rápido porque solo comprobamos la cabecera HTTP.
        
        # Para hacerlo más rápido, primero obtenemos el número total de episodios
        # de la temporada 1 como referencia, o simplemente probamos hasta encontrar un 404.
        # Como esto puede ser lento, vamos a hacer una estimación basada en la URL.
        
        # NOTA: Para evitar lentitud, vamos a generar un rango fijo (ej. 1 a 30).
        # Si la serie tiene menos, los enlaces darán error 404 y los ignoramos.
        # Si tiene más, tendrás que aumentar el rango.
        
        # Extraer el slug de la serie de la URL (ej: "epitafios")
        slug = url.strip("/").split("/")[-1]
        
        xbmc.log(f"Reypelis: Generando episodios para Temporada {season_num} de {slug}", xbmc.LOGINFO)
        
        # Generamos URLs para los episodios del 1 al 30
        for i in range(1, 31):
            ep_url = f"{BASE_URL}/capitulo/{slug}-temporada-{season_num}-capitulo-{i}/"
            ep_title = f"{series_title} Temporada {season_num} Capítulo {i}"
            
            # Comprobamos si la URL existe (HEAD request)
            try:
                r = SESSION.head(ep_url, timeout=5)
                if r.status_code == 200:
                    episodes.append({"num": str(i), "title": ep_title, "url": ep_url})
                else:
                    # Si da 404, asumimos que no hay más episodios en esta temporada
                    break
            except:
                break

    if not episodes:
        xbmcgui.Dialog().ok("Reypelis", f"No se encontraron episodios para la Temporada {season_num}.")
        return

    # 3. Mostrar los episodios
    for ep in episodes:
        ep_label = f"Temporada {season_num} - Episodio {ep['num']}"
        li = xbmcgui.ListItem(label=ep_label)
        li.setInfo("video", {"title": ep_label, "plot": plot})
        
        # Al pulsar un episodio, llamamos a detail_movie() o play() directamente.
        # Como los episodios tienen la misma estructura que las películas (iframes),
        # usamos la función detail_movie() pero le pasamos un "action" diferente para que sepa que es un episodio.
        # Para simplificar, usamos 'detail' y la función detail() ya redirigirá.
        
        # Como la URL es de /capitulo/, la función detail() actual lo tratará como película (porque no tiene /serie/).
        # Eso es perfecto, porque detail_movie() extrae los iframes y los muestra.
        params = {"action": "detail", "url": ep["url"], "title": ep_title}
        xbmcplugin.addDirectoryItem(HANDLE, build_url(params), li, isFolder=True)

    xbmcplugin.endOfDirectory(HANDLE)
    
# =====================================================================
# REPRODUCCIÓN CON PROXY
# =====================================================================
def play(embed_url, title):
    xbmc.log(f"Reypelis: === INICIANDO PLAY ===", xbmc.LOGINFO)
    try:
        # 1. Obtener URL de Fastream
        r = SESSION.get(embed_url, timeout=15)
        r.raise_for_status()
        match_fastream = re.search(r'SRC="(https://fastream\.to/embed-[^"]+)"', r.text, re.IGNORECASE)
        if not match_fastream:
            soup = BeautifulSoup(r.text, 'html.parser')
            iframe = soup.find('iframe')
            if iframe and iframe.get('src'):
                fastream_url = iframe['src']
            else:
                xbmcgui.Dialog().ok("Reypelis", "No se encontró el reproductor.")
                xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
                return
        else:
            fastream_url = match_fastream.group(1)

        # 2. Extraer URL del .m3u8
        headers_fastream = {
            "User-Agent": USER_AGENT,
            "Referer": "https://reypelis.net/",
            "Accept": "*/*"
        }
        r_fast = SESSION.get(fastream_url, headers=headers_fastream, timeout=15)
        r_fast.raise_for_status()
        html_fast = r_fast.text

        script_blocks = re.findall(r'<script[^>]*>(.*?)</script>', html_fast, re.DOTALL | re.IGNORECASE)
        unpacked_code = None
        for script in script_blocks:
            if 'eval(function(p,a,c,k,e,d)' in script:
                unpacked = unpack_js(script)
                if unpacked:
                    unpacked_code = unpacked
                    break
        search_target = unpacked_code if unpacked_code else html_fast
        match_file = re.search(r'file\s*:\s*["\'](https?://[^"\']+\.m3u8[^"\']*)["\']', search_target)
        if match_file:
            m3u8_url = match_file.group(1)
        else:
            match_m3u8 = re.search(r'(https?://[^\s"\'<>]+\.m3u8[^\s"\'<>]*)', search_target)
            if match_m3u8:
                m3u8_url = match_m3u8.group(1)
            else:
                xbmcgui.Dialog().ok("Reypelis", "No se pudo extraer el enlace .m3u8.")
                xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
                return

        # 3. Iniciar el proxy local con el Referer correcto
        start_proxy(fastream_url)

        # 4. Pasar la URL del m3u8 A TRAVÉS DEL PROXY
        proxied_m3u8 = f"http://127.0.0.1:{PROXY_PORT}/proxy?url={urllib.parse.quote(m3u8_url, safe='')}"
        
        xbmc.log(f"Reypelis: Reproduciendo vía proxy: {proxied_m3u8}", xbmc.LOGINFO)

        li = xbmcgui.ListItem(path=proxied_m3u8)
        li.setMimeType("application/vnd.apple.mpegurl")
        li.setContentLookup(False)
        li.setProperty("inputstream", "inputstream.adaptive")
        li.setProperty("inputstream.adaptive.manifest_type", "hls")
        
        # Le decimos a ISA que NO use las cabeceras del ListItem, porque el proxy ya las añade
        # (Evitamos que ISA sobrescriba las cabeceras del proxy)
        
        xbmcplugin.setResolvedUrl(HANDLE, True, li)
        xbmc.log("Reypelis: === FIN PLAY ===", xbmc.LOGINFO)

    except Exception as e:
        xbmc.log(f"Reypelis: ERROR en play(): {e}", xbmc.LOGERROR)
        xbmcgui.Dialog().ok("Reypelis", f"Error al reproducir:\n{str(e)}")
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())

# =====================================================================
# ROUTER
# =====================================================================
if __name__ == "__main__":
    params = dict(urllib.parse.parse_qsl(sys.argv[2][1:])) if len(sys.argv) > 2 else {}
    action = params.get("action", "")
    if action == "":
        main_menu()
    elif action == "list":
        list_content(params["url"])
    elif action == "search":
        search()
    elif action == "genres":
        list_genres()
    elif action == "detail":
        detail(params["url"], params.get("title", ""))
    elif action == "list_episodes":
        # Ahora recibe url, season y title
        list_episodes(params["url"], params["season"], params["title"])
    elif action == "play":
        play(params["url"], params.get("title", ""))
    elif action == "download":        # <-- NUEVO
        download(params["url"], params["title"])        
    else:
        main_menu()